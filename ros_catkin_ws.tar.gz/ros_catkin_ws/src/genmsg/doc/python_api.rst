genmsg Python API
=================

.. module:: genmsg

Classes
-------

.. autoclass:: MsgSpec
   :members:

.. autoclass:: SrvSpec
   :members:

.. autoclass:: Constant
   :members:

.. autoclass:: Field
   :members:
